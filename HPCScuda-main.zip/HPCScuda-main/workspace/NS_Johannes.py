import cupy
import numpy
import subprocess
import matplotlib.pyplot as plt
from matplotlib import pyplot, cm
from mpl_toolkits.mplot3d import Axes3D
import time
import line_profiler as lp
from cupyx.profiler import benchmark

cuda_compile_flags = ('--use_fast_math','--extra-device-vectorization')

def build_up_b(b, rho, dt, u, v, dx, dy):
    b[1:-1, 1:-1] = (rho * (1 / dt * 
                    ((u[1:-1, 2:] - u[1:-1, 0:-2]) / 
                     (2 * dx) + (v[2:, 1:-1] - v[0:-2, 1:-1]) / (2 * dy)) -
                    ((u[1:-1, 2:] - u[1:-1, 0:-2]) / (2 * dx))**2 -
                      2 * ((u[2:, 1:-1] - u[0:-2, 1:-1]) / (2 * dy) *
                           (v[1:-1, 2:] - v[1:-1, 0:-2]) / (2 * dx))-
                          ((v[2:, 1:-1] - v[0:-2, 1:-1]) / (2 * dy))**2))
    return b

def pressure_poisson(p, dx, dy, b):
    pn = xp.empty_like(p) #allocate temporary matrix pn
    
    p,pn=pn,p #swap pointers so that pn holds the initial data. This way we can avoid copying data unnecessarily
    
    for q in range(nit):
        if xp is cupy:
            #Running on GPU
            pnu = pn[0:-2, 1:-1]
            pnd = pn[2:, 1:-1]
            pnl = pn[1:-1, 0:-2]
            pnr = pn[1:-1, 2:]
            p[1:-1, 1:-1] = p_equation(pnu, pnd, pnl, pnr, dx, dy, b[1:-1, 1:-1])
            #p[1:-1, 1:-1] = p_equation(pnu, pnd, pnl, pnr, dx, dy, b[1:-1, 1:-1], block_size=128)
        else:
            #Running on CPU
            p[1:-1, 1:-1] = (((pn[1:-1, 2:] + pn[1:-1, 0:-2]) * dy**2 + 
                          (pn[2:, 1:-1] + pn[0:-2, 1:-1]) * dx**2) /
                          (2 * (dx**2 + dy**2)) -
                          dx**2 * dy**2 / (2 * (dx**2 + dy**2)) * 
                          b[1:-1,1:-1])
        
        p[:, -1] = p[:, -2] # dp/dx = 0 at x = 2
        p[0, :] = p[1, :]   # dp/dy = 0 at y = 0
        p[:, 0] = p[:, 1]   # dp/dx = 0 at x = 0
        p[-1, :] = 0        # p = 0 at y = 2
        
        #no copy, just swap pointers
        p,pn=pn,p
        #pn now holds result of latest iteration, ready for next iteration
    return pn

b_equation =cupy.ElementwiseKernel ('T ul, T ur, T uu, T ud, T vl, T vr, T vu, T vd, T rho, T dt, T dx, T dy', 'T b',
    'b = (rho * (1 / dt * ((ur - ul) /(2 * dx) + (vd - vu) / (2 * dy)) - ((ur - ul) / (2 * dx))*((ur - ul) / (2 * dx)) - 2 * ((ud - uu) / (2 * dy) * (vr - vl) / (2 * dx))- ((vd - vu) / (2 * dy))*((vd - vu) / (2 * dy))))',
    'b_equation', options=cuda_compile_flags)

p_equation = cupy.ElementwiseKernel('T pnu, T pnd, T pnl, T pnr, T dx, T dy, T b', 'T p',
    'p = (((pnr + pnl) * dy*dy +  (pnd + pnu) * dx*dx) / (2 * (dx*dx + dy*dy)) - dx*dx * dy*dy / (2 * (dx*dx + dy*dy)) * b)',
    'p_equation', options=cuda_compile_flags)

u_equation =cupy.ElementwiseKernel ('T un, T vn, T unl, T unr, T unu, T und, T pl, T pr, T nu, T rho, T dt, T dx, T dy', 'T u',
    'u = (un-un * dt / dx * (un - unl) - vn * dt / dy * (un - unu) - dt / (2 * rho * dx) * (pr - pl) + nu * (dt / dx*dx * (unr - 2 * un + unl) + dt / dy*dy * (und - 2 * un + unu)))',
    'u_equation', options=cuda_compile_flags)

v_equation =cupy.ElementwiseKernel ('T vn, T un, T vnl, T vnr, T vnu, T vnd, T pd, T pu, T nu, T rho, T dt, T dx, T dy', 'T v',
    'v = (vn - un * dt / dx * (vn - vnl) - vn * dt / dy * (vn - vnu) - dt / (2 * rho * dy) * (pd - pu) + nu * (dt / dx*dx * (vnr - 2 * vn + vnl) + dt / dy*dy * (vnd - 2 * vn + vnu)))',
    'v_equation', options=cuda_compile_flags)

def cavity_flow(nt, u, v, dt, dx, dy, p, rho, nu):
    un = xp.zeros_like(u)
    vn = xp.zeros_like(v)
    b = xp.zeros_like(p)
    
    for n in range(nt):
        #When we reach this statement, the latest timestep is saved in u and v
        #We could copy this data to un and vn, but here we just swap pointers to save a copy operation
        u,un=un,u
        v,vn=vn,v
        
        #convenience definitions for use with GPU
        unu = un[0:-2, 1:-1]
        und = un[2:, 1:-1]
        unl = un[1:-1, 0:-2]
        unr = un[1:-1, 2:]
        vnu = vn[0:-2, 1:-1]
        vnd = vn[2:, 1:-1]
        vnl = vn[1:-1, 0:-2]
        vnr = vn[1:-1, 2:]
        pl = p[1:-1, 0:-2]
        pr = p[1:-1, 2:]
        pu = p[0:-2, 1:-1]
        pd = p[2:, 1:-1]
        
        if xp is cupy:
            #Running on GPU
            b[1:-1, 1:-1] = b_equation(unl, unr, unu, und, vnl, vnr, vnu, vnd, rho, dt, dx, dy)
        else:
            #Running on CPU
            b = build_up_b(b, rho, dt, un, vn, dx, dy)
        
        p = pressure_poisson(p, dx, dy, b)
        
        if xp is cupy:
            #Running on GPU
            u[1:-1, 1:-1] = u_equation(un[1:-1, 1:-1], vn[1:-1, 1:-1], unl, unr, unu, und, pl, pr, nu, rho, dt, dx, dy)
            v[1:-1, 1:-1] = v_equation(vn[1:-1, 1:-1], un[1:-1, 1:-1], vnl, vnr, vnu, vnd, pd, pu, nu, rho, dt, dx, dy)
        else:
            #Running on CPU
            u[1:-1, 1:-1] = (un[1:-1, 1:-1]-
                            un[1:-1, 1:-1] * dt / dx *
                            (un[1:-1, 1:-1] - un[1:-1, 0:-2]) -
                            vn[1:-1, 1:-1] * dt / dy *
                            (un[1:-1, 1:-1] - un[0:-2, 1:-1]) -
                            dt / (2 * rho * dx) * (p[1:-1, 2:] - p[1:-1, 0:-2]) +
                            nu * (dt / dx**2 *
                            (un[1:-1, 2:] - 2 * un[1:-1, 1:-1] + un[1:-1, 0:-2]) +
                            dt / dy**2 *
                            (un[2:, 1:-1] - 2 * un[1:-1, 1:-1] + un[0:-2, 1:-1])))
    
            v[1:-1,1:-1] = (vn[1:-1, 1:-1] -
                            un[1:-1, 1:-1] * dt / dx *
                        (vn[1:-1, 1:-1] - vn[1:-1, 0:-2]) -
                            vn[1:-1, 1:-1] * dt / dy *
                        (vn[1:-1, 1:-1] - vn[0:-2, 1:-1]) -
                            dt / (2 * rho * dy) * (p[2:, 1:-1] - p[0:-2, 1:-1]) +
                            nu * (dt / dx**2 *
                        (vn[1:-1, 2:] - 2 * vn[1:-1, 1:-1] + vn[1:-1, 0:-2]) +
                            dt / dy**2 *
                        (vn[2:, 1:-1] - 2 * vn[1:-1, 1:-1] + vn[0:-2, 1:-1])))
        
        
        u[0, :]  = 0
        u[:, 0]  = 0
        u[:, -1] = 0
        u[-1, :] = 1    # set velocity on cavity lid equal to 1
        v[0, :]  = 0
        v[-1, :] = 0
        v[:, 0]  = 0
        v[:, -1] = 0
        
        
    return u, v, p

#Run performance measurement for set of matrix dimensions (nx_list) and alternating CPU/GPU (run_on_gpu_list)

#List of matrix dimensions to test
#For GPU: fist run seems to have an extra delay. Run small case in the beginning to prevent this from affecting the profiling results
#nx_list = [128, 128, 256, 512, 1024, 2048, 4096, 8192, 16384]
nx_list = [128, 128, 256, 512, 1024, 2048, 4096, 8192]
#nx_list = [128]
#nx_list = [41]

#Run on CPU and/or GPU
run_on_gpu_list = [0,1] #Run on both CPU and GPU
#run_on_gpu_list = [0] #Run only on CPU
#run_on_gpu_list = [1] #Run only on GPU

plot_results = 0 #[bool] Set to 0 for profiling, maybe 1 for debugging
show_hardware_info = 1 #[bool] Set to 1 for full info, 0 for shorter output

nt = 10 #NB! Value lowered from original code so that profiling runs don't take too much time
nit = 10 #NB! Inaccurate with only 10! Same comment as line above
c = 1

rho = 1
nu = .1
dt = .000001 #Needs to be very small to be stable with a very fine grid

data_type = numpy.float32 #Data type to be used for matrices

if show_hardware_info:
    cpu_info = subprocess.run('lscpu');
    gpu_info = subprocess.run("nvidia-smi -L".split());

#Table headings for profiling output data
print("#run_on_gpu [bool]\tnx [-]\ttime [s]\t\tBenchmark result ->")

for nx in nx_list:
    for run_on_gpu in run_on_gpu_list:
        if run_on_gpu:
            import cupy as xp
        else:
            import numpy as xp
            
        ny = nx
        dx = 2 / (nx - 1)
        dy = 2 / (ny - 1)
        
        u = xp.zeros((ny, nx), dtype=data_type) #NB! Change here to get float or double
        v = xp.zeros_like(u)
        p = xp.zeros_like(u)
        
        #Code for actual profiling.
        #The cavity_flow() call together with the synchronize() calls take about the same time as benchmark()
        #Both profiling methods are probably fine
        cupy.cuda.stream.get_current_stream().synchronize()
        start_iterative = time.time()
        #u, v, p = cavity_flow(nt, u, v, dt, dx, dy, p, rho, nu)
        benchmark_result = benchmark(cavity_flow, (nt, u, v, dt, dx, dy, p, rho, nu,), n_warmup=0, n_repeat=1)
        cupy.cuda.stream.get_current_stream().synchronize()
        end_iterative = time.time()
        
        #print line for table of profiling results
        print(f'{run_on_gpu}\t\t\t{nx}\t{end_iterative - start_iterative}\t{benchmark_result}')
        #print(benchmark_result)
        
        if plot_results:
            x = xp.linspace(0, 2, nx)
            y = xp.linspace(0, 2, ny)
            X, Y = xp.meshgrid(x, y)
            if run_on_gpu:
                X = X.get()
                Y = Y.get()
                p = p.get()
                u = u.get()
                v = v.get()
            
            fig = pyplot.figure(figsize=(11,7), dpi=100)
            # plotting the pressure field as a contour
            pyplot.contourf(X, Y, p, alpha=0.5, cmap=cm.viridis)  
            pyplot.colorbar()
            # plotting the pressure field outlines
            pyplot.contour(X, Y, p, cmap=cm.viridis)  
            # plotting velocity field
            pyplot.quiver(X[::2, ::2], Y[::2, ::2], u[::2, ::2], v[::2, ::2]) 
            pyplot.xlabel('X')
            pyplot.ylabel('Y');
            pyplot.show()


